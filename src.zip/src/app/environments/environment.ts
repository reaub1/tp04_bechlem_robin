export const environment = {
    production: false,
    backendProduit: '/assets/mock/produits.json',
  };
  