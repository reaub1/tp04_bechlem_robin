import {Produit} from '../models/produit';
export class PanierStateModel {
  produits: Produit[] | undefined;
}
